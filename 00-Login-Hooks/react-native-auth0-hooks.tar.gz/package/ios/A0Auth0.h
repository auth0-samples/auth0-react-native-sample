#import <React/RCTBridgeModule.h>

@interface A0Auth0 : NSObject <RCTBridgeModule>

@end

@class CredentialsManagerBridge;
