module.exports = {name: 'react-native-auth0', version: '2.13.3'};
