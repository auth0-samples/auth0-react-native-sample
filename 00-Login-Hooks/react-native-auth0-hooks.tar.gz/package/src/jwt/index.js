import {verifyToken} from './validator';

export default verifyToken;
